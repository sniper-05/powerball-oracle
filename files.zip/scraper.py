import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime
import os

def scrape_powerball():
    url = "https://portalseven.com/lottery/powerball_winning_numbers.jsp?viewType=2&timeRange=5"
    headers = {"User-Agent": "Mozilla/5.0 (compatible; PowerballScraper/1.0)"}

    print(f"[{datetime.now()}] Fetching Powerball data...")
    response = requests.get(url, headers=headers, timeout=15)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    table = soup.find("table", {"class": "dataTable"}) or soup.find("table")

    draws = []
    if table:
        rows = table.find_all("tr")[1:]  # skip header
        for row in rows:
            cells = row.find_all("td")
            if len(cells) >= 7:
                try:
                    date_str = cells[0].get_text(strip=True)
                    nums = [int(cells[i].get_text(strip=True)) for i in range(1, 6)]
                    pb = int(cells[6].get_text(strip=True))
                    draws.append({
                        "date": date_str,
                        "numbers": nums,
                        "powerball": pb
                    })
                except (ValueError, IndexError):
                    continue

    print(f"[{datetime.now()}] Scraped {len(draws)} draws.")

    output = {
        "last_updated": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "total_draws": len(draws),
        "draws": draws
    }

    os.makedirs("data", exist_ok=True)
    with open("data/draws.json", "w") as f:
        json.dump(output, f, indent=2)

    print(f"[{datetime.now()}] Saved to data/draws.json")
    return len(draws)

if __name__ == "__main__":
    count = scrape_powerball()
    print(f"Done. {count} draws saved.")
